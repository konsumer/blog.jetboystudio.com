$('a[data-port]').each(function(){
  $(this).attr('href', 'http://' + document.location.hostname + ':' + $(this).data('port') );
});

$('#ip').html(document.location.hostname);

function getReadableFileSizeString(fileSizeInBytes) {
  var i = -1;
  var byteUnits = [' kB', ' MB', ' GB', ' TB', 'PB', 'EB', 'ZB', 'YB'];
  do {
    fileSizeInBytes = fileSizeInBytes / 1024;
    i++;
  } while (fileSizeInBytes > 1024);
  return Math.max(fileSizeInBytes, 0.1).toFixed(2) + byteUnits[i];
};

function getFreespace(){
  $.getJSON('freespace.php?dir=/share', function(data){
    var percent = ((data.free / data.total) * 100).toFixed(2);
    $('#free').html(getReadableFileSizeString(data.free));
    $('#total').html(getReadableFileSizeString(data.total));
    $('#percent').html(percent);
    setTimeout(getFreespace, 1000);
  });
}
getFreespace();