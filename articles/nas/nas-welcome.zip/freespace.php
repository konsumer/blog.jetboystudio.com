<?php

$dir = !empty($_GET['dir']) ? $_GET['dir'] : '/';

print json_encode(array(
	'free'=>disk_free_space($dir),
	'total'=>disk_total_space($dir)
)); 